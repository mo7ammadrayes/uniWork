SELECT 
    SUM(cases) AS total_cases
  ,SUM(deaths) AS total_deaths
FROM 
    Case_Death_Records;

